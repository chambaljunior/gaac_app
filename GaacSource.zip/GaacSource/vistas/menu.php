<div id="sidebar" style=" background: -webkit-linear-gradient(-50deg, rgb(151, 199, 148), rgb(18, 101, 108));">
	<div class="inner" style="">

	<!-- Menu -->
		<nav id="menu">
			<header>
				<center>
				<img src="../images/nnema.png" alt="Logotipo-GAAC" height="35px">
				<hr>
				</center>
			</header>
			<ul style="">
				<li style="color: white;"><a href="index.php?link=1"><center>PAGINA INCIAL</center></a></li>
				<li style="color: white;"><a href="index.php?link=2"><center><i class="fas fa-users-cog fa-2x"></i><br>GESTAO GAAC</center></a></li>
				<li style="color: white;"><a href="index.php?link=3"><center> <i class="fas fa-user-plus fa-2x"></i><br>MEMBRO GAAC</center></a></li>
				<li style="color: white;"><a href="index.php?link=4"><center> <i class="fas fa-notes-medical fa-2x"></i><br>CLINICA HIV</center></a></li>
				<li style="color: white;"><a href="index.php?link=5"><center> <i class="fas fa-chat fa-2x"></i></center></a></li>
				<li style="color: white;"><a href="index.php?link=6"><center><i class="fas fa-home fa-2x "></i><br>ALDEIAS</center></a></li>
				<li style="color: white;"><a href="https://nnema.000webhostapp.com/"><center>FECHAR SESSAO</center></a></li>
			</ul>
		</nav>

		

	</div>
</div>