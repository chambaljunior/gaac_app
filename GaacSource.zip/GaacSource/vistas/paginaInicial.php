<div id="main" style="background: -webkit-linear-gradient(-50deg, rgb(147, 176, 187), rgb(61, 122, 166));">
	<div class="inner">
	<!-- Banner -->
		<section id="banner">
			<div class="content">
				<center>
					<img src="../images/nnema.png" alt="Logotipo-GAAC" height="45%" style="padding-top:25%;">
					<br>
					<h1 style="color: white;">GAAC</h1>
				</center>
			</div>
		</section>

	</div>
</div>