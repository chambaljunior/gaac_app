<?php

	$conexao = mysqli_connect("localhost","root","","gaacbd");

?>