<div id="sidebar" style=" background: -webkit-linear-gradient(-50deg, rgb(165, 137, 176), rgb(211, 92, 92));">
						<div class="inner">
	<footer id="footer">
	</footer>
</div>
</div>	