<div id="main">
	<div class="inner">
	<!-- Banner -->
		<section id="banner">
			<div class="content">
				<header>
					<h1>Entrevista</h1>
                    <input type="checkbox" name="sintoma[]" value="Tosse por 3 semanas ou mais">
				</header>
				<center>
		        <form method="POST" action="../../controladora/registarGrupo.php">
                    <label for="fname">Data</label>
                    <input type="checkbox" name="">
                    <input type="date" id="ngg" name="ngg" class="ngg" placeholder="GAAC...">
                    <label for="country">Membro</label>
                    <select id="aldeia" name="aldeia">
                        <?php
                            
                        ?>    
                    </select>
             <label class="container">Tosse por 3 semanas ou mais.
                <input type="checkbox" name="sintoma[]" value="Tosse por 3 semanas ou mais">
                <span class="checkmark"></span>
            </label>
            <label class="container">Tosse com sangue.
                <input type="checkbox" name="sintoma[]" value="Tosse com sangue">
                <span class="checkmark"></span>
            </label>
            <label class="container">Dor no peito.
                <input type="checkbox" name="sintoma[]" value="Dor no peito">
                <span class="checkmark"></span>
            </label>
            <label class="container">Dor quando respira.
                <input type="checkbox" name="sintoma[]" value="Dor quando respira">
                <span class="checkmark"></span>
            </label><label class="container">Dor quando tosse.
                <input type="checkbox" name="sintoma[]" value="Dor quando tosse">
                <span class="checkmark"></span>
            </label><label class="container">Cansaço.
                <input type="checkbox" name="sintoma[]" value="Cansaço">
                <span class="checkmark"></span>
            </label><label class="container">Febre.
                <input type="checkbox" name="sintoma[]" value="Febre">
                <span class="checkmark"></span>
            </label><label class="container">Formigueiro ou arrepios.
                <input type="checkbox" name="sintoma[]" value="Formigueiro ou arrepios">
                <span class="checkmark"></span>
            </label>


            <hr>
            <label class="container">Feses liquidas por mais de 2 dias.
                <input type="checkbox" name="sintoma[]" value="Feses liquidas por mais de 2 dias">
                <span class="checkmark"></span>
            </label>
            <label class="container">Sangue nas feses.
                <input type="checkbox" name="sintoma[]" value="Sangue nas feses">
                <span class="checkmark"></span>
            </label>
            <label class="container">Nausea.
                <input type="checkbox" name="sintoma[]" value="Nausea">
                <span class="checkmark"></span>
            </label>
            <label class="container">Vomito.
                <input type="checkbox" name="sintoma[]" value="Vomito">
                <span class="checkmark"></span>
            </label><label class="container">Dor de estomago.
                <input type="checkbox" name="sintoma[]" value="Dor de estomago">
                <span class="checkmark"></span>
            </label><label class="container">Inchaço abdominal.
                <input type="checkbox" name="sintoma[]" value="Inchaço abdominal">
                <span class="checkmark"></span>
            </label><label class="container">Manchas violetas no corpo.
                <input type="checkbox" name="sintoma[]" value="Manchas violetas no corpo">
                <span class="checkmark"></span>
            </label><label class="container">Comichão no corpo.
                <input type="checkbox" name="sintoma[]" value="Comichão no corpo">
                <span class="checkmark"></span>
            </label>


            <hr>
            <label class="container">Dor quando urina.
                <input type="checkbox" name="sintoma[]" value="Dor quando urina">
                <span class="checkmark"></span>
            </label>
            <label class="container">Feridas no sexo.
                <input type="checkbox" name="sintoma[]" value="Feridas no sexo">
                <span class="checkmark"></span>
            </label>
            <label class="container">Verrugas no sexo.
                <input type="checkbox" name="sintoma[]" value="Verrugas no sexo">
                <span class="checkmark"></span>
            </label><label class="container">Inchaços no sexo.
                <input type="checkbox" name="sintoma[]" value="Inchaços no sexo">
                <span class="checkmark"></span>
            </label><label class="container">Comichão no sexo.
                <input type="checkbox" name="sintoma[]" value="Comichão no sexo">
                <span class="checkmark"></span>
            </label>
            <label class="container">Dor durante as relações sexuais.
                <input type="checkbox" name="sintoma[]" value="Dor durante as relações sexuais">
                <span class="checkmark"></span>
            </label>
                    <input type="submit" value="Criar GAAC">
                </form>
		            </center>
							</div>
		</section>

	</div>
</div>

