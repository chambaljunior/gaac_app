<?php

	$conexao = mysqli_connect("localhost","id11408406_chambaljr","123456","id11408406_gaac");

?>